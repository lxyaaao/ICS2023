/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_156(unsigned *p)
{
    *p = 1791201400U;
}

unsigned addval_299(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_438(unsigned x)
{
    return x + 2438511437U;
}

unsigned addval_461(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_443(unsigned x)
{
    return x + 3351742792U;
}

unsigned addval_267(unsigned x)
{
    return x + 2425393240U;
}

unsigned addval_407(unsigned x)
{
    return x + 3347662972U;
}

void setval_414(unsigned *p)
{
    *p = 3284631880U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_123()
{
    return 3286272264U;
}

void setval_351(unsigned *p)
{
    *p = 3675838089U;
}

unsigned addval_380(unsigned x)
{
    return x + 2447411528U;
}

void setval_480(unsigned *p)
{
    *p = 3221804553U;
}

unsigned getval_497()
{
    return 3229928065U;
}

unsigned getval_307()
{
    return 3281049224U;
}

void setval_278(unsigned *p)
{
    *p = 3221801613U;
}

unsigned getval_328()
{
    return 2497743176U;
}

unsigned addval_273(unsigned x)
{
    return x + 2462157289U;
}

unsigned getval_257()
{
    return 2497743176U;
}

unsigned addval_125(unsigned x)
{
    return x + 3223896457U;
}

unsigned addval_362(unsigned x)
{
    return x + 3374369417U;
}

unsigned addval_146(unsigned x)
{
    return x + 3229931145U;
}

void setval_473(unsigned *p)
{
    *p = 3687110281U;
}

unsigned addval_227(unsigned x)
{
    return x + 3676359307U;
}

unsigned getval_452()
{
    return 3229931017U;
}

void setval_343(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_492()
{
    return 3286272328U;
}

void setval_472(unsigned *p)
{
    *p = 3526934921U;
}

unsigned addval_471(unsigned x)
{
    return x + 3683959177U;
}

unsigned addval_249(unsigned x)
{
    return x + 3529556361U;
}

unsigned getval_223()
{
    return 2425471369U;
}

unsigned getval_204()
{
    return 3264266633U;
}

unsigned getval_266()
{
    return 3223374473U;
}

unsigned getval_417()
{
    return 449042057U;
}

unsigned getval_478()
{
    return 3523794585U;
}

unsigned addval_105(unsigned x)
{
    return x + 3374893705U;
}

unsigned addval_141(unsigned x)
{
    return x + 3281177225U;
}

unsigned addval_142(unsigned x)
{
    return x + 3286272328U;
}

void setval_162(unsigned *p)
{
    *p = 3676357001U;
}

void setval_444(unsigned *p)
{
    *p = 3676359337U;
}

unsigned addval_326(unsigned x)
{
    return x + 3269495112U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
